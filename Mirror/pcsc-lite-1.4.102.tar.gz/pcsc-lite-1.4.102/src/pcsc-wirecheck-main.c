void pcsc_assert_wire_constants(void);

int
main (int argc, char **argv)
{
    pcsc_assert_wire_constants ();
    return 0;
}
