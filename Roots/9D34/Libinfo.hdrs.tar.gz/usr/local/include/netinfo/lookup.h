#ifndef	_lookup_user_
#define	_lookup_user_

/* Module lookup */

#include <string.h>
#include <mach/ndr.h>
#include <mach/boolean.h>
#include <mach/kern_return.h>
#include <mach/notify.h>
#include <mach/mach_types.h>
#include <mach/message.h>
#include <mach/mig_errors.h>
#include <mach/port.h>

#ifdef AUTOTEST
#ifndef FUNCTION_PTR_T
#define FUNCTION_PTR_T
typedef void (*function_ptr_t)(mach_port_t, char *, mach_msg_type_number_t);
typedef struct {
        char            *name;
        function_ptr_t  function;
} function_table_entry;
typedef function_table_entry 	*function_table_t;
#endif /* FUNCTION_PTR_T */
#endif /* AUTOTEST */

#ifndef	lookup_MSG_COUNT
#define	lookup_MSG_COUNT	4
#endif	/* lookup_MSG_COUNT */

#include <netinfo/lookup_types.h>
#include <mach/std_types.h>
#include <mach/mig.h>
#include <mach/mig.h>
#include <mach/mach_types.h>

#ifdef __BeforeMigUserHeader
__BeforeMigUserHeader
#endif /* __BeforeMigUserHeader */

#include <sys/cdefs.h>
__BEGIN_DECLS


/* Routine _lookup_link_secure */
#ifdef	mig_external
mig_external
#else
extern
#endif	/* mig_external */
kern_return_t _lookup_link_secure
(
	mach_port_t server,
	lookup_name name,
	int *procno,
	security_token_t *token
);

/* Routine _lookup_all_secure */
#ifdef	mig_external
mig_external
#else
extern
#endif	/* mig_external */
kern_return_t _lookup_all_secure
(
	mach_port_t server,
	int proc,
	inline_data indata,
	mach_msg_type_number_t indataCnt,
	ooline_data *outdata,
	mach_msg_type_number_t *outdataCnt,
	security_token_t *token
);

/* Routine _lookup_one_secure */
#ifdef	mig_external
mig_external
#else
extern
#endif	/* mig_external */
kern_return_t _lookup_one_secure
(
	mach_port_t server,
	int proc,
	inline_data indata,
	mach_msg_type_number_t indataCnt,
	inline_data outdata,
	mach_msg_type_number_t *outdataCnt,
	security_token_t *token
);

/* Routine _lookup_ooall_secure */
#ifdef	mig_external
mig_external
#else
extern
#endif	/* mig_external */
kern_return_t _lookup_ooall_secure
(
	mach_port_t server,
	int proc,
	ooline_data indata,
	mach_msg_type_number_t indataCnt,
	ooline_data *outdata,
	mach_msg_type_number_t *outdataCnt,
	security_token_t *token
);

__END_DECLS

/********************** Caution **************************/
/* The following data types should be used to calculate  */
/* maximum message sizes only. The actual message may be */
/* smaller, and the position of the arguments within the */
/* message layout may vary from what is presented here.  */
/* For example, if any of the arguments are variable-    */
/* sized, and less than the maximum is sent, the data    */
/* will be packed tight in the actual message to reduce  */
/* the presence of holes.                                */
/********************** Caution **************************/

/* typedefs for all requests */

#ifndef __Request__lookup_subsystem__defined
#define __Request__lookup_subsystem__defined

#ifdef  __MigPackStructs
#pragma pack(4)
#endif
	typedef struct {
		mach_msg_header_t Head;
		NDR_record_t NDR;
		lookup_name name;
	} __Request___lookup_link_secure_t;
#ifdef  __MigPackStructs
#pragma pack()
#endif

#ifdef  __MigPackStructs
#pragma pack(4)
#endif
	typedef struct {
		mach_msg_header_t Head;
		NDR_record_t NDR;
		int proc;
		mach_msg_type_number_t indataCnt;
		unit indata[4096];
	} __Request___lookup_all_secure_t;
#ifdef  __MigPackStructs
#pragma pack()
#endif

#ifdef  __MigPackStructs
#pragma pack(4)
#endif
	typedef struct {
		mach_msg_header_t Head;
		NDR_record_t NDR;
		int proc;
		mach_msg_type_number_t indataCnt;
		unit indata[4096];
	} __Request___lookup_one_secure_t;
#ifdef  __MigPackStructs
#pragma pack()
#endif

#ifdef  __MigPackStructs
#pragma pack(4)
#endif
	typedef struct {
		mach_msg_header_t Head;
		/* start of the kernel processed data */
		mach_msg_body_t msgh_body;
		mach_msg_ool_descriptor_t indata;
		/* end of the kernel processed data */
		NDR_record_t NDR;
		int proc;
		mach_msg_type_number_t indataCnt;
	} __Request___lookup_ooall_secure_t;
#ifdef  __MigPackStructs
#pragma pack()
#endif
#endif /* !__Request__lookup_subsystem__defined */

/* union of all requests */

#ifndef __RequestUnion__lookup_subsystem__defined
#define __RequestUnion__lookup_subsystem__defined
union __RequestUnion__lookup_subsystem {
	__Request___lookup_link_secure_t Request__lookup_link_secure;
	__Request___lookup_all_secure_t Request__lookup_all_secure;
	__Request___lookup_one_secure_t Request__lookup_one_secure;
	__Request___lookup_ooall_secure_t Request__lookup_ooall_secure;
};
#endif /* !__RequestUnion__lookup_subsystem__defined */
/* typedefs for all replies */

#ifndef __Reply__lookup_subsystem__defined
#define __Reply__lookup_subsystem__defined

#ifdef  __MigPackStructs
#pragma pack(4)
#endif
	typedef struct {
		mach_msg_header_t Head;
		NDR_record_t NDR;
		kern_return_t RetCode;
		int procno;
	} __Reply___lookup_link_secure_t;
#ifdef  __MigPackStructs
#pragma pack()
#endif

#ifdef  __MigPackStructs
#pragma pack(4)
#endif
	typedef struct {
		mach_msg_header_t Head;
		/* start of the kernel processed data */
		mach_msg_body_t msgh_body;
		mach_msg_ool_descriptor_t outdata;
		/* end of the kernel processed data */
		NDR_record_t NDR;
		mach_msg_type_number_t outdataCnt;
	} __Reply___lookup_all_secure_t;
#ifdef  __MigPackStructs
#pragma pack()
#endif

#ifdef  __MigPackStructs
#pragma pack(4)
#endif
	typedef struct {
		mach_msg_header_t Head;
		NDR_record_t NDR;
		kern_return_t RetCode;
		mach_msg_type_number_t outdataCnt;
		unit outdata[4096];
	} __Reply___lookup_one_secure_t;
#ifdef  __MigPackStructs
#pragma pack()
#endif

#ifdef  __MigPackStructs
#pragma pack(4)
#endif
	typedef struct {
		mach_msg_header_t Head;
		/* start of the kernel processed data */
		mach_msg_body_t msgh_body;
		mach_msg_ool_descriptor_t outdata;
		/* end of the kernel processed data */
		NDR_record_t NDR;
		mach_msg_type_number_t outdataCnt;
	} __Reply___lookup_ooall_secure_t;
#ifdef  __MigPackStructs
#pragma pack()
#endif
#endif /* !__Reply__lookup_subsystem__defined */

/* union of all replies */

#ifndef __ReplyUnion__lookup_subsystem__defined
#define __ReplyUnion__lookup_subsystem__defined
union __ReplyUnion__lookup_subsystem {
	__Reply___lookup_link_secure_t Reply__lookup_link_secure;
	__Reply___lookup_all_secure_t Reply__lookup_all_secure;
	__Reply___lookup_one_secure_t Reply__lookup_one_secure;
	__Reply___lookup_ooall_secure_t Reply__lookup_ooall_secure;
};
#endif /* !__RequestUnion__lookup_subsystem__defined */

#ifndef subsystem_to_name_map_lookup
#define subsystem_to_name_map_lookup \
    { "_lookup_link_secure", 4241775 },\
    { "_lookup_all_secure", 4241776 },\
    { "_lookup_one_secure", 4241777 },\
    { "_lookup_ooall_secure", 4241778 }
#endif

#ifdef __AfterMigUserHeader
__AfterMigUserHeader
#endif /* __AfterMigUserHeader */

#endif	 /* _lookup_user_ */
