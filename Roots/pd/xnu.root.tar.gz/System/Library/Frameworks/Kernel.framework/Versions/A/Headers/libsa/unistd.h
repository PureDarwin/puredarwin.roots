#ifndef _LIBSA_UNISTD_H_
#define _LIBSA_UNISTD_H_


#define getpagesize()    PAGE_SIZE


#endif /* _LIBSA_UNISTD_H_ */
